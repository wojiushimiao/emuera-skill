"""authoring package"""
