"""kernel_bridge package"""
